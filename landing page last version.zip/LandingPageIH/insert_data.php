<?php

if(isset($_POST['submit'])){

 
  $name = $_POST['name'];
  $email = $_POST['email'];
  $subject = $_POST['subject'];
  $message = $_POST['message'];
 
    $secret_key ='6LdL8WogAAAAAMASHdnVOf36oDh0_Rj5Va26cpvj
    ';
    // https://www.google.com/recaptcha/api/siteverify?secret=6LfJU2QgAAAAAGh0watzDH69LAEszLEf7t6LldA0&response=g-recaptcha-response
    if($_SERVER["REQUEST_METHOD"] === "POST"){
      // prepare post variables
      $post = [
          'secret' => $secret_key,
          'response' => $_POST['g-recaptcha-response'],
      ];
  
      $ch = curl_init('https://www.google.com/recaptcha/api/siteverify');
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
  
      $response = curl_exec($ch);
      curl_close($ch);
  
      var_dump($response);
      $response = json_decode($response, true);
  
      // check result
      if(isset($response['success']) && $response['success'] == true){

        echo '<script>alert("Google reCAPTACHA verified")</script>';
    
        include ("connect.php");
        mysqli_query ($conn,"INSERT INTO mail (name, email, subject, message) VALUES ('$name', '$email', '$subject', '$message' )");
        var_dump($response);
      }else{
        echo '<script>alert("Error in Google reCAPTACHA")</script>';
      }
  }
  
   


}


?>