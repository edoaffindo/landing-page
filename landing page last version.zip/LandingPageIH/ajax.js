$(document).ready(function () {
  $("#form").validate({
    rules: {
      name: "required",
      email: "required",
      message: "required",
    },
    errorElement: "span",
    messages: {
      name: "<span style='color:red'>Harap masukkan nama kamu</span>",
      email: "<span style='color:red' >Harap masukkan email kamu</span>",
      message: "<span style='color:red'>Harap masukkan pesan kamu</span>",
    },
    submitHandler: function (form) {
      var dataparam = $("#form").serialize();

      $.ajax({
        type: "POST",
        async: true,
        url: "insert_data.php",
        data: dataparam,
        datatype: "json",
        cache: true,
        global: false,
        beforeSend: function () {
          $("#loader").show();
        },
        success: function (data) {
          if (data == "success") {
            console.log(data);
          } else {
            $(".no-config").show();
            console.log(data);
          }
        },

        complete: function () {
          $("#loader").hide();
          document.getElementById("form").reset();
        },
      });
    },
  });
});
