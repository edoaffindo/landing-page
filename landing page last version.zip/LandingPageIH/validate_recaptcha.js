var recaptcha_res = "";
function submitform() {
  if (recaptcha_res.length == 0) {
    document.getElementById("g-recaptcha-error").innerHTML =
      '<span style="color:red">Harap verifikasi recaptcha</span>';
    return false;
  }

  return true;
}

function verifyCaptcha(token) {
  recaptcha_res = token;
  document.getElementById("g-recaptcha-error").innerHTML = "";
}
