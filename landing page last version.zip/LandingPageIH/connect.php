<?php 
$dbhost ='localhost';
$username ='root';
$password ='';
$dbname ='landingpage';

$conn=mysqli_connect($dbhost,$username,$password,$dbname);

if(!$conn) {
    die("gagal konek ke mysql: ". mysqli_connect_error());

}

echo "database konek sukses";



?>